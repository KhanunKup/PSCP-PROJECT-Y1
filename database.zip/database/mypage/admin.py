from django.contrib import admin
from mypage.models import creativereser,peer1reser,peer2reser, peer3reser

# Register your models here.
admin.site.register(creativereser)
admin.site.register(peer1reser)
admin.site.register(peer2reser)
admin.site.register(peer3reser)